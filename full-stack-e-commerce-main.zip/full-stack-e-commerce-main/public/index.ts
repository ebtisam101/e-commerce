import banner_1 from "./banner/banner_1.png"
import paymentLogo from "./payment.png"
import paypalLogo from "./paypalLogo.png"
import emptyCart from "./emptyCart.png"
export {paymentLogo, paypalLogo, banner_1, emptyCart}